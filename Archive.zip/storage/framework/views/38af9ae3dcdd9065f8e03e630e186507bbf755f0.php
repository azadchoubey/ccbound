<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /Users/azadchoubey/Downloads/buysale 20 July/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>